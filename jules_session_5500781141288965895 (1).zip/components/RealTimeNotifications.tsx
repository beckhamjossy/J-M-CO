'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingBag, Eye, UserCheck } from 'lucide-react';

const ACTIVITIES = [
  { icon: <ShoppingBag size={16} />, text: 'Someone just booked a viewing in Financial District' },
  { icon: <Eye size={16} />, text: '12 people are currently looking at Horizon Penthouse' },
  { icon: <UserCheck size={16} />, text: 'New investment inquiry from Diaspora client' },
  { icon: <ShoppingBag size={16} />, text: 'Azure Bay Villa has a new offer!' },
  { icon: <Eye size={16} />, text: 'Premium office space in Commercial Hub just got 5 views' },
];

export const RealTimeNotifications = () => {
  const [index, setIndex] = useState(0);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const showTimeout = setTimeout(() => setVisible(true), 5000);
    
    const interval = setInterval(() => {
      setVisible(false);
      setTimeout(() => {
        setIndex((prev) => (prev + 1) % ACTIVITIES.length);
        setVisible(true);
      }, 500);
    }, 15000);

    return () => {
      clearTimeout(showTimeout);
      clearInterval(interval);
    };
  }, []);

  return (
    <div className="fixed bottom-6 left-6 z-[100] pointer-events-none">
      <AnimatePresence>
        {visible && (
          <motion.div
            initial={{ opacity: 0, x: -100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
            className="bg-white/95 backdrop-blur-md border border-slate-100 shadow-2xl p-4 rounded-xl flex items-center gap-4 max-w-sm pointer-events-auto"
          >
            <div className="w-10 h-10 rounded-full bg-gold/10 text-gold flex items-center justify-center shrink-0">
              {ACTIVITIES[index].icon}
            </div>
            <div>
              <p className="text-navy text-sm font-semibold">{ACTIVITIES[index].text}</p>
              <p className="text-[10px] text-muted uppercase font-bold tracking-widest mt-1">Just Now</p>
            </div>
            <button 
              onClick={() => setVisible(false)}
              className="text-muted hover:text-navy transition-colors ml-2"
            >
              ×
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
