'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { PropertyCard, Property } from './PropertyCard';
import { Button } from './ui/Button';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';

const FEATURED_PROPERTIES: Property[] = [
  {
    id: '1',
    title: 'Horizon Penthouse',
    price: '$2,450,000',
    location: 'Financial District, City Center',
    type: 'Residential',
    beds: 4,
    baths: 3,
    area: '3,200',
    image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
    isFeatured: true
  },
  {
    id: '2',
    title: 'Elite Plaza Suites',
    price: '$1,200,000',
    location: 'Commercial Hub, North Side',
    type: 'Commercial',
    beds: 0,
    baths: 2,
    area: '1,850',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
    yield: '8.5%',
    isFeatured: true
  },
  {
    id: '3',
    title: 'Azure Bay Villa',
    price: '$3,800,000',
    location: 'Coastal Bay, West Coast',
    type: 'Residential',
    beds: 5,
    baths: 5,
    area: '5,400',
    image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
    isFeatured: true
  }
];

export const FeaturedListings = () => {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-2xl">
            <span className="text-gold font-bold uppercase tracking-[0.2em] text-sm block mb-4">Handpicked Selection</span>
            <h2 className="text-3xl md:text-5xl font-bold text-navy">Featured Listings</h2>
            <p className="text-muted mt-4 text-lg">
              Explore our exclusive collection of high-value properties curated for discerning clients.
            </p>
          </div>
          <Link href="/properties">
            <Button variant="outline" className="flex gap-2">
              View All Properties <ArrowRight size={18} />
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {FEATURED_PROPERTIES.map((property, index) => (
            <motion.div
              key={property.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <PropertyCard property={property} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
