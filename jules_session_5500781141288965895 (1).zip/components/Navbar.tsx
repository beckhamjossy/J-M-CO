'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Menu, X, Phone, User } from 'lucide-react';
import { Button } from './ui/Button';

export const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '/' },
    { name: 'Properties', href: '/properties' },
    { name: 'Invest', href: '/#invest' },
    { name: 'About', href: '/about' },
    { name: 'Blog', href: '/blog' },
    { name: 'Contact', href: '/contact' },
  ];

  return (
    <nav 
      className={`fixed w-full z-50 transition-all duration-500 ${
        scrolled ? 'bg-white shadow-xl py-3' : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2">
            <div className="bg-navy p-1.5 rounded">
              <span className="text-gold font-black text-2xl leading-none">J&M</span>
            </div>
            <span className={`font-bold text-xl tracking-tighter ${scrolled ? 'text-navy' : 'text-white'}`}>
              CO
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link 
                key={link.name} 
                href={link.href}
                className={`text-sm font-semibold uppercase tracking-widest transition-colors hover:text-gold ${
                  scrolled ? 'text-navy' : 'text-white'
                }`}
              >
                {link.name}
              </Link>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-4">
            <Button variant={scrolled ? 'primary' : 'outline'} size="sm" className="hidden lg:flex gap-2">
              <Phone size={16} />
              <span>Contact Agent</span>
            </Button>
            <Link href="/login">
              <div className={`p-2 rounded-full border transition-all ${
                scrolled ? 'border-navy/10 text-navy' : 'border-white/20 text-white'
              } hover:bg-gold hover:text-white hover:border-gold`}>
                <User size={20} />
              </div>
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className={`${scrolled ? 'text-navy' : 'text-white'} focus:outline-none`}
            >
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      <div className={`md:hidden absolute w-full bg-white shadow-2xl transition-all duration-300 ease-in-out ${
        isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-full pointer-events-none'
      }`}>
        <div className="px-4 pt-2 pb-6 space-y-1 sm:px-3 border-t border-slate-100">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              href={link.href}
              className="block px-3 py-4 text-base font-bold text-navy border-b border-slate-50"
              onClick={() => setIsOpen(false)}
            >
              {link.name}
            </Link>
          ))}
          <div className="pt-4 flex flex-col gap-3">
            <Button variant="gold" className="w-full">Book Consultation</Button>
            <Button variant="primary" className="w-full">Sign In</Button>
          </div>
        </div>
      </div>
    </nav>
  );
};
