'use client';

import React, { useState } from 'react';
import { Input } from './ui/Input';
import { TrendingUp } from 'lucide-react';

export const InvestmentROICalculator = () => {
  const [purchasePrice, setPurchasePrice] = useState(1200000);
  const [monthlyRent, setMonthlyRent] = useState(8500);
  const [expenses, setExpenses] = useState(1200);

  const annualNetIncome = (monthlyRent - expenses) * 12;
  const roi = (annualNetIncome / purchasePrice) * 100;

  return (
    <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-xl">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 rounded-lg bg-gold/10 flex items-center justify-center text-gold">
          <TrendingUp size={24} />
        </div>
        <h3 className="text-2xl font-bold text-navy">ROI Calculator</h3>
      </div>

      <div className="space-y-6">
        <div>
          <label className="text-xs font-bold uppercase tracking-wider text-muted block mb-2">Purchase Price ($)</label>
          <Input 
            type="number" 
            value={purchasePrice} 
            onChange={(e) => setPurchasePrice(Number(e.target.value))} 
          />
        </div>

        <div>
          <label className="text-xs font-bold uppercase tracking-wider text-muted block mb-2">Expected Monthly Rent ($)</label>
          <Input 
            type="number" 
            value={monthlyRent} 
            onChange={(e) => setMonthlyRent(Number(e.target.value))} 
          />
        </div>

        <div>
          <label className="text-xs font-bold uppercase tracking-wider text-muted block mb-2">Monthly Expenses ($)</label>
          <Input 
            type="number" 
            value={expenses} 
            onChange={(e) => setExpenses(Number(e.target.value))} 
          />
        </div>

        <div className="mt-10 p-6 bg-navy rounded-xl text-center">
          <p className="text-slate-400 text-sm font-bold uppercase tracking-widest mb-2">Annual Cap Rate / ROI</p>
          <h4 className="text-4xl font-bold text-gold">
            {roi.toFixed(2)}%
          </h4>
        </div>
      </div>
    </div>
  );
};
