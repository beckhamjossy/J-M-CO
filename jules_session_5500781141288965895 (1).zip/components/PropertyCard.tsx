import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Bed, Bath, Square, MapPin, TrendingUp } from 'lucide-react';
import { Button } from './ui/Button';

export interface Property {
  id: string;
  title: string;
  price: string;
  location: string;
  type: string;
  beds: number;
  baths: number;
  area: string;
  image: string;
  yield?: string;
  isFeatured?: boolean;
}

interface PropertyCardProps {
  property: Property;
}

export const PropertyCard = ({ property }: PropertyCardProps) => {
  return (
    <div className="group bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-500 border border-slate-100 flex flex-col h-full">
      <div className="relative h-64 overflow-hidden">
        <Image
          src={property.image}
          alt={property.title}
          fill
          className="object-cover group-hover:scale-110 transition-transform duration-700"
        />
        <div className="absolute top-4 left-4 flex flex-col gap-2">
          <span className="bg-navy text-white px-3 py-1 rounded text-xs font-bold uppercase tracking-wider">
            {property.type}
          </span>
          {property.yield && (
            <span className="bg-gold text-white px-3 py-1 rounded text-xs font-bold flex items-center gap-1">
              <TrendingUp size={12} /> {property.yield} Yield
            </span>
          )}
        </div>
        <div className="absolute bottom-4 right-4">
          <span className="bg-white/95 backdrop-blur-sm text-navy px-4 py-2 rounded-lg font-bold text-lg shadow-lg">
            {property.price}
          </span>
        </div>
      </div>
      
      <div className="p-6 flex flex-col flex-grow">
        <h3 className="text-xl font-bold text-navy mb-2 group-hover:text-gold transition-colors duration-300">
          {property.title}
        </h3>
        <div className="flex items-center text-muted mb-4 text-sm">
          <MapPin size={16} className="mr-1 text-gold" />
          {property.location}
        </div>
        
        <div className="grid grid-cols-3 gap-4 border-y border-slate-100 py-4 mb-6">
          <div className="flex flex-col items-center gap-1">
            <div className="flex items-center gap-1 text-navy font-semibold">
              <Bed size={18} className="text-gold" />
              {property.beds}
            </div>
            <span className="text-[10px] uppercase text-muted tracking-widest font-bold">Beds</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <div className="flex items-center gap-1 text-navy font-semibold">
              <Bath size={18} className="text-gold" />
              {property.baths}
            </div>
            <span className="text-[10px] uppercase text-muted tracking-widest font-bold">Baths</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <div className="flex items-center gap-1 text-navy font-semibold">
              <Square size={16} className="text-gold" />
              {property.area}
            </div>
            <span className="text-[10px] uppercase text-muted tracking-widest font-bold">Sq Ft</span>
          </div>
        </div>
        
        <div className="mt-auto flex gap-3">
          <Link href={`/properties/${property.id}`} className="flex-1">
            <Button variant="outline" className="w-full">Details</Button>
          </Link>
          <Button variant="gold" className="px-4">
            Inquire
          </Button>
        </div>
      </div>
    </div>
  );
};
