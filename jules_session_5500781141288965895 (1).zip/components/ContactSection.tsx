'use client';

import React, { useState } from 'react';
import { Button } from './ui/Button';
import { Input } from './ui/Input';
import { MessageSquare, Phone, Mail, MapPin, CheckCircle2 } from 'lucide-react';

export const ContactSection = () => {
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setStatus('loading');
    
    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData.entries());

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...data, type: 'general_inquiry' }),
      });

      if (response.ok) {
        setStatus('success');
      } else {
        setStatus('error');
      }
    } catch {
      setStatus('error');
    }
  };

  if (status === 'success') {
    return (
      <section className="py-24 bg-navy relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="bg-white rounded-3xl p-12 text-center flex flex-col items-center justify-center min-h-[500px]">
            <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6">
              <CheckCircle2 size={48} />
            </div>
            <h2 className="text-3xl font-bold text-navy mb-4">Inquiry Received!</h2>
            <p className="text-muted text-lg max-w-md">
              Thank you for reaching out. We have sent a notification to our team at beckhamjossyo@gmail.com and will get back to you shortly.
            </p>
            <Button variant="gold" className="mt-8" onClick={() => setStatus('idle')}>
              Send Another Message
            </Button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-24 bg-navy relative overflow-hidden">
      <div className="absolute top-0 right-0 w-1/3 h-full bg-gold/5 -skew-x-12 translate-x-1/2" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="bg-white rounded-3xl overflow-hidden shadow-2xl flex flex-col lg:flex-row">
          <div className="lg:w-2/5 bg-navy p-12 text-white">
            <h2 className="text-3xl font-bold mb-8">Get In Touch</h2>
            <p className="text-slate-400 mb-12">
              Ready to start your real estate journey? Fill out the form and our specialist will contact you within 24 hours.
            </p>
            
            <div className="space-y-8">
              <div className="flex gap-6 items-center">
                <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center text-gold">
                  <Phone size={24} />
                </div>
                <div>
                  <p className="text-xs text-slate-500 uppercase font-bold tracking-widest mb-1">Call Us</p>
                  <p className="text-lg font-bold">+1 (555) 123-4567</p>
                </div>
              </div>
              
              <div className="flex gap-6 items-center">
                <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center text-gold">
                  <Mail size={24} />
                </div>
                <div>
                  <p className="text-xs text-slate-500 uppercase font-bold tracking-widest mb-1">Email Us</p>
                  <p className="text-lg font-bold">hello@jmco.com</p>
                </div>
              </div>

              <div className="flex gap-6 items-center">
                <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center text-gold">
                  <MessageSquare size={24} />
                </div>
                <div>
                  <p className="text-xs text-slate-500 uppercase font-bold tracking-widest mb-1">WhatsApp</p>
                  <p className="text-lg font-bold">Chat with an Expert</p>
                </div>
              </div>
            </div>
            
            <div className="mt-16 pt-16 border-t border-slate-800">
              <p className="text-gold font-bold uppercase tracking-widest text-xs mb-4">Our Office</p>
              <div className="flex gap-3 text-slate-400">
                <MapPin size={20} className="shrink-0" />
                <span>123 Luxury Lane, Elite Plaza, Financial District</span>
              </div>
            </div>
          </div>

          <div className="lg:w-3/5 p-12 bg-white">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-navy">Full Name</label>
                  <Input name="name" required placeholder="John Doe" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-navy">Email Address</label>
                  <Input name="email" type="email" required placeholder="john@example.com" />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-navy">Phone Number</label>
                  <Input name="phone" placeholder="+1 (555) 000-0000" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-navy">Interest</label>
                  <select name="interest" className="flex h-12 w-full rounded-md border border-border bg-white px-4 py-2 text-navy focus:outline-none focus:ring-2 focus:ring-gold">
                    <option>Buying</option>
                    <option>Selling</option>
                    <option>Investment</option>
                    <option>Commercial</option>
                  </select>
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-bold text-navy">Your Message</label>
                <textarea 
                  name="message"
                  required
                  className="flex min-h-[150px] w-full rounded-md border border-border bg-white px-4 py-3 text-navy focus:outline-none focus:ring-2 focus:ring-gold"
                  placeholder="Tell us about your requirements..."
                />
              </div>
              
              <Button 
                type="submit" 
                variant="gold" 
                className="w-full h-14 text-lg font-bold uppercase tracking-widest"
                disabled={status === 'loading'}
              >
                {status === 'loading' ? 'Sending...' : 'Send Inquiry'}
              </Button>
              {status === 'error' && <p className="text-red-500 text-sm text-center">Something went wrong. Please try again.</p>}
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};
