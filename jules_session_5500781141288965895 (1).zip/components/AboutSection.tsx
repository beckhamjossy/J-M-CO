'use client';

import React from 'react';
import { motion } from 'framer-motion';
import Image from 'next/image';
import { Button } from './ui/Button';
import Link from 'next/link';

export const AboutSection = () => {
  return (
    <section className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="lg:w-1/2 relative"
          >
            <div className="relative z-10 rounded-2xl overflow-hidden shadow-2xl aspect-[4/5]">
              <Image 
                src="https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                alt="J&M CO Leadership" 
                fill 
                className="object-cover"
              />
            </div>
            {/* Experience Badge */}
            <div className="absolute -bottom-10 -right-10 z-20 bg-white p-8 rounded-2xl shadow-2xl border-t-4 border-gold hidden sm:block">
              <span className="text-5xl font-black text-navy block mb-1">15+</span>
              <span className="text-sm font-bold text-muted uppercase tracking-widest">Years of Excellence</span>
            </div>
            {/* Decorative background */}
            <div className="absolute top-10 left-10 -z-10 w-full h-full border-2 border-gold/20 rounded-2xl translate-x-4 translate-y-4" />
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="lg:w-1/2"
          >
            <span className="text-gold font-bold uppercase tracking-[0.2em] text-sm block mb-4">Our Legacy</span>
            <h2 className="text-3xl md:text-5xl font-bold text-navy mb-8 leading-tight">Expertise You Can Trust, <br />Service You Deserve</h2>
            <div className="space-y-6 text-muted text-lg leading-relaxed mb-10">
              <p>
                Founded on the principles of integrity and excellence, J&M CO has grown from a boutique agency into a leading force in the luxury real estate market.
              </p>
              <p>
                Our mission is to empower our clients with the knowledge and opportunities they need to make confident real estate decisions. Whether you&apos;re a first-time buyer or a seasoned investor, we provide the same level of premium, personalized service.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-8 mb-12">
              <div>
                <span className="text-3xl font-bold text-navy block mb-1">500+</span>
                <p className="text-sm text-muted font-semibold uppercase tracking-wider">Properties Sold</p>
              </div>
              <div>
                <span className="text-3xl font-bold text-navy block mb-1">$2B+</span>
                <p className="text-sm text-muted font-semibold uppercase tracking-wider">Asset Value Managed</p>
              </div>
            </div>

            <Link href="/about">
              <Button size="lg">Learn More About Us</Button>
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
