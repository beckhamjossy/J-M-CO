import React from 'react';
import Link from 'next/link';
import { Mail, Phone, MapPin, Facebook, Instagram, Twitter, Linkedin, ArrowRight } from 'lucide-react';
import { Button } from './ui/Button';

export const Footer = () => {
  return (
    <footer className="bg-navy text-white pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="space-y-6">
            <Link href="/" className="flex items-center gap-2">
              <div className="bg-white p-1 rounded">
                <span className="text-navy font-black text-2xl leading-none">J&M</span>
              </div>
              <span className="text-white font-bold text-xl tracking-tighter">CO</span>
            </Link>
            <p className="text-slate-400 leading-relaxed">
              J&M CO is a premium real estate firm dedicated to providing exceptional service and expertise in residential, commercial, and investment properties.
            </p>
            <div className="flex gap-4">
              {[Facebook, Instagram, Twitter, Linkedin].map((Icon, i) => (
                <Link key={i} href="#" className="w-10 h-10 rounded-full border border-slate-700 flex items-center justify-center hover:bg-gold hover:border-gold transition-colors">
                  <Icon size={18} />
                </Link>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6 text-gold">Quick Links</h4>
            <ul className="space-y-4 text-slate-400">
              <li><Link href="/properties" className="hover:text-white transition-colors">Featured Properties</Link></li>
              <li><Link href="/about" className="hover:text-white transition-colors">Our Story</Link></li>
              <li><Link href="/#invest" className="hover:text-white transition-colors">Investment Portfolios</Link></li>
              <li><Link href="/blog" className="hover:text-white transition-colors">Market Insights</Link></li>
              <li><Link href="/contact" className="hover:text-white transition-colors">Contact Us</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6 text-gold">Contact Us</h4>
            <ul className="space-y-4 text-slate-400">
              <li className="flex gap-3 items-start">
                <MapPin className="text-gold shrink-0" size={20} />
                <span>123 Luxury Lane, Elite Plaza, Financial District</span>
              </li>
              <li className="flex gap-3 items-center">
                <Phone className="text-gold shrink-0" size={20} />
                <span>+1 (555) 123-4567</span>
              </li>
              <li className="flex gap-3 items-center">
                <Mail className="text-gold shrink-0" size={20} />
                <span>info@jmco-realestate.com</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-6 text-gold">Newsletter</h4>
            <p className="text-slate-400 mb-6">Subscribe to receive the latest property updates and investment opportunities.</p>
            <div className="flex flex-col gap-3">
              <input 
                type="email" 
                placeholder="Email Address" 
                className="bg-slate-800 border-none rounded-md px-4 py-3 focus:ring-2 focus:ring-gold outline-none text-white w-full"
              />
              <Button variant="gold" className="w-full flex gap-2">
                Subscribe <ArrowRight size={18} />
              </Button>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-800 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-slate-500">
          <p>© {new Date().getFullYear()} J&M CO Real Estate. All rights reserved.</p>
          <div className="flex gap-8">
            <Link href="#" className="hover:text-white transition-colors">Privacy Policy</Link>
            <Link href="#" className="hover:text-white transition-colors">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};
