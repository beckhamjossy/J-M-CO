'use client';

import React from 'react';
import { Search, MapPin, Home, DollarSign, Percent } from 'lucide-react';
import { Button } from './ui/Button';
import { Select } from './ui/Input';

export const SearchFilter = () => {
  return (
    <div className="max-w-6xl mx-auto px-4 -mt-24 relative z-20">
      <div className="bg-white p-6 md:p-8 rounded-2xl shadow-2xl border border-slate-100">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-muted flex items-center gap-2">
              <MapPin size={14} className="text-gold" /> Location
            </label>
            <Select>
              <option>All Locations</option>
              <option>Financial District</option>
              <option>Luxury Heights</option>
              <option>Coastal Bay</option>
              <option>Commercial Hub</option>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-muted flex items-center gap-2">
              <Home size={14} className="text-gold" /> Property Type
            </label>
            <Select>
              <option>All Types</option>
              <option>Residential</option>
              <option>Commercial</option>
              <option>Investment</option>
              <option>Off-plan</option>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-muted flex items-center gap-2">
              <DollarSign size={14} className="text-gold" /> Price Range
            </label>
            <Select>
              <option>Any Price</option>
              <option>$200k - $500k</option>
              <option>$500k - $1M</option>
              <option>$1M - $5M</option>
              <option>$5M+</option>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold uppercase tracking-wider text-muted flex items-center gap-2">
              <Percent size={14} className="text-gold" /> Min Yield
            </label>
            <Select>
              <option>Any Yield</option>
              <option>5%+</option>
              <option>7%+</option>
              <option>10%+</option>
            </Select>
          </div>

          <div className="flex items-end">
            <Button variant="gold" className="w-full h-12 flex gap-2 font-bold uppercase tracking-widest text-sm">
              <Search size={18} /> Search
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
