import React from 'react';
import Image from 'next/image';
import { Button } from './ui/Button';
import { TrendingUp, Building2, Landmark } from 'lucide-react';
import { InvestmentROICalculator } from './InvestmentROICalculator';

const OPPORTUNITIES = [
  {
    icon: <TrendingUp className="text-gold" />,
    title: 'Rental Income Potential',
    description: 'High-yield residential properties in prime locations with proven rental track records.',
    image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
  },
  {
    icon: <Building2 className="text-gold" />,
    title: 'Off-Plan Projects',
    description: 'Early-stage investment opportunities in premium developments with significant capital growth potential.',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
  },
  {
    icon: <Landmark className="text-gold" />,
    title: 'Commercial Portfolios',
    description: 'Stable, long-term returns through diversified commercial real estate assets.',
    image: 'https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
  }
];

export const InvestmentOpportunities = () => {
  return (
    <section id="invest" className="py-24 bg-navy text-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          <div className="lg:w-1/2">
            <span className="text-gold font-bold uppercase tracking-[0.2em] text-sm block mb-4">Grow Your Wealth</span>
            <h2 className="text-3xl md:text-5xl font-bold mb-8">Investment Opportunities</h2>
            <p className="text-slate-400 text-lg mb-10 leading-relaxed">
              We provide tailored investment strategies for local and diaspora clients. From high-yield rentals to strategic commercial acquisitions, we help you build a robust property portfolio.
            </p>
            
            <div className="space-y-8">
              {OPPORTUNITIES.map((opp, index) => (
                <div key={index} className="flex gap-6 group">
                  <div className="shrink-0 w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center group-hover:bg-gold transition-colors duration-300">
                    {opp.icon}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">{opp.title}</h3>
                    <p className="text-slate-400 text-sm leading-relaxed">{opp.description}</p>
                  </div>
                </div>
              ))}
            </div>
            
            <Button variant="gold" size="lg" className="mt-12">
              Explore Investment Portfolios
            </Button>

            <div className="mt-16 text-navy">
              <InvestmentROICalculator />
            </div>
          </div>
          
          <div className="lg:w-1/2 relative">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4 pt-12">
                <div className="relative h-64 rounded-2xl overflow-hidden shadow-2xl">
                  <Image src={OPPORTUNITIES[0].image} alt="Investment 1" fill className="object-cover" />
                </div>
                <div className="relative h-48 rounded-2xl overflow-hidden shadow-2xl">
                  <Image src={OPPORTUNITIES[2].image} alt="Investment 2" fill className="object-cover" />
                </div>
              </div>
              <div className="space-y-4">
                <div className="relative h-48 rounded-2xl overflow-hidden shadow-2xl">
                  <Image src={OPPORTUNITIES[1].image} alt="Investment 3" fill className="object-cover" />
                </div>
                <div className="relative h-64 rounded-2xl overflow-hidden shadow-2xl bg-gold flex items-center justify-center p-8 text-center">
                  <div>
                    <span className="text-4xl font-bold text-navy block mb-2">12%+</span>
                    <p className="text-navy/70 text-xs font-bold uppercase tracking-widest">Avg. Annual ROI</p>
                  </div>
                </div>
              </div>
            </div>
            {/* Decorative elements */}
            <div className="absolute -z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-gold/5 rounded-full blur-3xl" />
          </div>
        </div>
      </div>
    </section>
  );
};
