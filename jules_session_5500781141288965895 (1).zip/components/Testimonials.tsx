import React from 'react';
import Image from 'next/image';
import { Star, Quote } from 'lucide-react';

const TESTIMONIALS = [
  {
    name: 'Sarah Jenkins',
    role: 'First-time Homeowner',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80',
    content: 'J&M CO made my dream of owning a home a reality. Their team was patient, professional, and helped me navigate the complex legal process with ease.',
    rating: 5
  },
  {
    name: 'David Chen',
    role: 'Property Investor',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80',
    content: "As an international investor, trust is everything. J&M CO has been my eyes and ears on the ground, consistently delivering high-yield opportunities.",
    rating: 5
  },
  {
    name: 'Elena Rodriguez',
    role: 'Corporate Client',
    image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&q=80',
    content: 'Finding commercial space that matched our brand identity was a challenge until we met the team at J&M CO. Highly recommended for business clients.',
    rating: 5
  }
];

export const Testimonials = () => {
  return (
    <section className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <span className="text-gold font-bold uppercase tracking-[0.2em] text-sm block mb-4">Client Success Stories</span>
          <h2 className="text-3xl md:text-5xl font-bold text-navy">What Our Clients Say</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((t, i) => (
            <div key={i} className="bg-slate-50 p-8 rounded-2xl relative">
              <Quote className="absolute top-6 right-8 text-gold/20" size={60} />
              <div className="flex gap-1 mb-6">
                {[...Array(t.rating)].map((_, i) => (
                  <Star key={i} size={16} className="fill-gold text-gold" />
                ))}
              </div>
              <p className="text-navy/80 italic mb-8 leading-relaxed">&ldquo;{t.content}&rdquo;</p>
              <div className="flex items-center gap-4">
                <div className="relative w-12 h-12 rounded-full overflow-hidden border-2 border-gold">
                  <Image src={t.image} alt={t.name} fill className="object-cover" />
                </div>
                <div>
                  <h4 className="font-bold text-navy">{t.name}</h4>
                  <p className="text-xs text-muted uppercase tracking-wider font-bold">{t.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
