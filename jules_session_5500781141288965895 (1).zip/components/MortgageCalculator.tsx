'use client';

import React, { useState } from 'react';
import { Input } from './ui/Input';
import { Calculator } from 'lucide-react';

export const MortgageCalculator = ({ defaultPrice = 2450000 }) => {
  const [price, setPrice] = useState(defaultPrice);
  const [downPayment, setDownPayment] = useState(defaultPrice * 0.2);
  const [interestRate, setInterestRate] = useState(4.5);
  const [loanTerm, setLoanTerm] = useState(30);

  const principal = price - downPayment;
  const monthlyRate = interestRate / 100 / 12;
  const numberOfPayments = loanTerm * 12;
  
  let monthlyPayment = 0;
  if (monthlyRate === 0) {
    monthlyPayment = principal / numberOfPayments;
  } else {
    const x = Math.pow(1 + monthlyRate, numberOfPayments);
    monthlyPayment = (principal * x * monthlyRate) / (x - 1);
  }

  return (
    <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-xl">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 rounded-lg bg-gold/10 flex items-center justify-center text-gold">
          <Calculator size={24} />
        </div>
        <h3 className="text-2xl font-bold text-navy">Mortgage Calculator</h3>
      </div>

      <div className="space-y-6">
        <div>
          <label className="text-xs font-bold uppercase tracking-wider text-muted block mb-2">Property Price ($)</label>
          <Input 
            type="number" 
            value={price} 
            onChange={(e) => setPrice(Number(e.target.value))} 
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-muted block mb-2">Down Payment ($)</label>
            <Input 
              type="number" 
              value={downPayment} 
              onChange={(e) => setDownPayment(Number(e.target.value))} 
            />
          </div>
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-muted block mb-2">Interest Rate (%)</label>
            <Input 
              type="number" 
              step="0.1"
              value={interestRate} 
              onChange={(e) => setInterestRate(Number(e.target.value))} 
            />
          </div>
        </div>

        <div>
          <label className="text-xs font-bold uppercase tracking-wider text-muted block mb-2">Loan Term (Years)</label>
          <select 
            className="flex h-12 w-full rounded-md border border-border bg-white px-4 py-2 text-navy focus:outline-none focus:ring-2 focus:ring-gold"
            value={loanTerm}
            onChange={(e) => setLoanTerm(Number(e.target.value))}
          >
            <option value={15}>15 Years</option>
            <option value={20}>20 Years</option>
            <option value={25}>25 Years</option>
            <option value={30}>30 Years</option>
          </select>
        </div>

        <div className="mt-10 p-6 bg-navy rounded-xl text-center">
          <p className="text-slate-400 text-sm font-bold uppercase tracking-widest mb-2">Estimated Monthly Payment</p>
          <h4 className="text-4xl font-bold text-gold">
            ${monthlyPayment.toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </h4>
        </div>
        
        <p className="text-[10px] text-muted text-center italic">
          * This is an estimate only. Actual rates and payments may vary based on lender and credit profile.
        </p>
      </div>
    </div>
  );
};
