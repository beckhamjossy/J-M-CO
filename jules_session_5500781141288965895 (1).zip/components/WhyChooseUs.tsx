'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, Zap, Scale, LineChart } from 'lucide-react';

const FEATURES = [
  {
    icon: <ShieldCheck size={32} className="text-gold" />,
    title: 'Market Expertise',
    description: 'Decades of combined experience in high-end real estate markets ensuring you get the best value.'
  },
  {
    icon: <Zap size={32} className="text-gold" />,
    title: 'Verified Listings',
    description: 'Every property in our portfolio undergoes a rigorous verification process for your peace of mind.'
  },
  {
    icon: <Scale size={32} className="text-gold" />,
    title: 'Legal & Documentation',
    description: 'Full support with contracts, legal paperwork, and property registration through our expert legal team.'
  },
  {
    icon: <LineChart size={32} className="text-gold" />,
    title: 'Investment Advisory',
    description: 'Data-driven insights and strategic advice for maximizing your property investment returns.'
  }
];

export const WhyChooseUs = () => {
  return (
    <section className="py-24 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-gold font-bold uppercase tracking-[0.2em] text-sm block mb-4">The J&M CO Advantage</span>
          <h2 className="text-3xl md:text-5xl font-bold text-navy mb-6">Why Choose J&M CO</h2>
          <p className="text-muted text-lg leading-relaxed">
            We redefine the real estate experience through transparency, innovation, and an unwavering commitment to our clients&apos; success.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {FEATURES.map((feature, index) => (
            <motion.div 
              key={index} 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 border border-slate-100 group"
            >
              <div className="mb-6 bg-slate-50 w-16 h-16 rounded-xl flex items-center justify-center group-hover:bg-navy group-hover:text-white transition-colors duration-300">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold text-navy mb-4">{feature.title}</h3>
              <p className="text-muted leading-relaxed text-sm">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
