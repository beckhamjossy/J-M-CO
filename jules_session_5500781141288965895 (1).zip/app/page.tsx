import { Hero } from "@/components/Hero";
import { SearchFilter } from "@/components/SearchFilter";
import { FeaturedListings } from "@/components/FeaturedListings";
import { WhyChooseUs } from "@/components/WhyChooseUs";
import { InvestmentOpportunities } from "@/components/InvestmentOpportunities";
import { Testimonials } from "@/components/Testimonials";
import { AboutSection } from "@/components/AboutSection";
import { ContactSection } from "@/components/ContactSection";

export default function Home() {
  return (
    <div className="flex flex-col w-full">
      <Hero />
      <SearchFilter />
      <FeaturedListings />
      <WhyChooseUs />
      <InvestmentOpportunities />
      <Testimonials />
      <AboutSection />
      <ContactSection />
    </div>
  );
}
