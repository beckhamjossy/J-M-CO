'use client';

import React from 'react';
import { PropertyCard, Property } from '@/components/PropertyCard';
import { SearchFilter } from '@/components/SearchFilter';

const ALL_PROPERTIES: Property[] = [
  {
    id: '1',
    title: 'Horizon Penthouse',
    price: '$2,450,000',
    location: 'Financial District, City Center',
    type: 'Residential',
    beds: 4,
    baths: 3,
    area: '3,200',
    image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
    isFeatured: true
  },
  {
    id: '2',
    title: 'Elite Plaza Suites',
    price: '$1,200,000',
    location: 'Commercial Hub, North Side',
    type: 'Commercial',
    beds: 0,
    baths: 2,
    area: '1,850',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
    yield: '8.5%',
    isFeatured: true
  },
  {
    id: '3',
    title: 'Azure Bay Villa',
    price: '$3,800,000',
    location: 'Coastal Bay, West Coast',
    type: 'Residential',
    beds: 5,
    baths: 5,
    area: '5,400',
    image: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
    isFeatured: true
  },
  {
    id: '4',
    title: 'Modern Loft',
    price: '$850,000',
    location: 'Arts District, Downtown',
    type: 'Residential',
    beds: 2,
    baths: 2,
    area: '1,500',
    image: 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
  },
  {
    id: '5',
    title: 'Silver Oak Estate',
    price: '$5,200,000',
    location: 'Elite Heights',
    type: 'Residential',
    beds: 6,
    baths: 7,
    area: '8,200',
    image: 'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
  },
  {
    id: '6',
    title: 'Tech Hub Office',
    price: '$950,000',
    location: 'Innovation Park',
    type: 'Commercial',
    beds: 0,
    baths: 4,
    area: '4,500',
    image: 'https://images.unsplash.com/photo-1497215728101-856f4ea42174?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80',
    yield: '7.2%'
  }
];

export default function ListingsPage() {
  return (
    <div className="pt-32 pb-24">
      <div className="bg-navy py-20 mb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Properties For Sale</h1>
          <p className="text-slate-400 max-w-2xl mx-auto">
            Discover our comprehensive range of residential, commercial, and investment properties tailored to your lifestyle and financial goals.
          </p>
        </div>
      </div>

      <div className="-mt-32">
        <SearchFilter />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-20">
        <div className="flex justify-between items-center mb-8">
          <p className="text-navy font-semibold">Showing {ALL_PROPERTIES.length} properties</p>
          <div className="flex gap-4">
            <select className="border-none bg-slate-100 rounded-md px-4 py-2 text-sm font-semibold text-navy focus:ring-2 focus:ring-gold">
              <option>Newest First</option>
              <option>Price: Low to High</option>
              <option>Price: High to Low</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {ALL_PROPERTIES.map((property) => (
            <PropertyCard key={property.id} property={property} />
          ))}
        </div>
      </div>
    </div>
  );
}
