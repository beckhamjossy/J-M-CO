'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useParams } from 'next/navigation';
import { Bed, Bath, MapPin, Share2, Heart, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { MortgageCalculator } from '@/components/MortgageCalculator';

// Re-using mock data for demonstration
const PROPERTIES = [
  {
    id: '1',
    title: 'Horizon Penthouse',
    price: '$2,450,000',
    location: 'Financial District, City Center',
    type: 'Residential',
    beds: 4,
    baths: 3,
    area: '3,200',
    image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80',
    description: 'This stunning penthouse offers breathtaking panoramic views of the city skyline. Featuring floor-to-ceiling windows, a private terrace, and bespoke finishes throughout, it defines urban luxury living.',
    features: ['Private Elevator', 'Smart Home System', '24/7 Concierge', 'Infinity Pool Access', 'Wine Cellar', 'Fitness Center']
  }
];

export default function PropertyDetailPage() {
  const { id } = useParams();
  const property = PROPERTIES.find(p => p.id === id) || PROPERTIES[0];
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');

  const handleBooking = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setStatus('loading');
    
    const formData = new FormData(e.currentTarget);
    const data = Object.fromEntries(formData.entries());

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...data, propertyId: id, propertyTitle: property.title, type: 'property_viewing' }),
      });

      if (response.ok) {
        setStatus('success');
      } else {
        setStatus('error');
      }
    } catch {
      setStatus('error');
    }
  };

  return (
    <div className="pt-24 pb-20">
      {/* Hero Gallery */}
      <div className="relative h-[60vh] min-h-[400px] w-full">
        <Image src={property.image} alt={property.title} fill className="object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-navy/60 to-transparent" />
        <div className="absolute bottom-10 left-0 w-full">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-end">
            <div>
              <span className="bg-gold text-white px-4 py-1 rounded text-sm font-bold uppercase tracking-wider mb-4 inline-block">
                {property.type}
              </span>
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-2">{property.title}</h1>
              <div className="flex items-center text-slate-200 gap-2">
                <MapPin size={20} className="text-gold" />
                {property.location}
              </div>
            </div>
            <div className="hidden md:flex gap-4">
              <Button variant="secondary" className="bg-white/10 text-white border-white/20 hover:bg-white/20">
                <Share2 size={20} className="mr-2" /> Share
              </Button>
              <Button variant="secondary" className="bg-white/10 text-white border-white/20 hover:bg-white/20">
                <Heart size={20} className="mr-2" /> Save
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        <div className="flex flex-col lg:flex-row gap-12">
          {/* Main Content */}
          <div className="lg:w-2/3">
            <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm mb-12">
              <div className="grid grid-cols-3 gap-8 mb-8 pb-8 border-b border-slate-100">
                <div className="flex flex-col gap-1">
                  <span className="text-muted text-xs uppercase font-bold tracking-widest">Price</span>
                  <span className="text-2xl font-bold text-navy">{property.price}</span>
                </div>
                <div className="flex flex-col gap-1">
                  <span className="text-muted text-xs uppercase font-bold tracking-widest">Bedrooms</span>
                  <div className="flex items-center gap-2 text-2xl font-bold text-navy">
                    <Bed size={24} className="text-gold" /> {property.beds}
                  </div>
                </div>
                <div className="flex flex-col gap-1">
                  <span className="text-muted text-xs uppercase font-bold tracking-widest">Bathrooms</span>
                  <div className="flex items-center gap-2 text-2xl font-bold text-navy">
                    <Bath size={24} className="text-gold" /> {property.baths}
                  </div>
                </div>
              </div>

              <h3 className="text-2xl font-bold text-navy mb-4">Description</h3>
              <p className="text-muted text-lg leading-relaxed mb-8">
                {property.description}
              </p>

              <h3 className="text-2xl font-bold text-navy mb-4">Features & Amenities</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {property.features.map((feature, i) => (
                  <div key={i} className="flex items-center gap-3 text-navy font-medium">
                    <CheckCircle2 size={20} className="text-gold" />
                    {feature}
                  </div>
                ))}
              </div>
            </div>

            {/* Placeholder for Virtual Tour */}
            <div className="bg-navy p-12 rounded-2xl mb-12 flex flex-col items-center justify-center text-center">
              <h3 className="text-2xl font-bold text-white mb-4">Experience a Virtual Tour</h3>
              <p className="text-slate-400 mb-8 max-w-md">Walk through this property from the comfort of your home with our high-definition 3D virtual tour.</p>
              <Button variant="gold" size="lg">Start Virtual Tour</Button>
            </div>

            <div id="mortgage-calc" className="scroll-mt-32">
              <MortgageCalculator defaultPrice={parseInt(property.price.replace(/[^0-9]/g, ''))} />
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:w-1/3">
            <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-xl sticky top-32">
              {status === 'success' ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-4 mx-auto">
                    <CheckCircle2 size={32} />
                  </div>
                  <h3 className="text-xl font-bold text-navy mb-2">Viewing Requested!</h3>
                  <p className="text-sm text-muted mb-6">Our agent has been notified at beckhamjossyo@gmail.com and will contact you shortly.</p>
                  <Button variant="outline" className="w-full" onClick={() => setStatus('idle')}>New Request</Button>
                </div>
              ) : (
                <>
                  <h3 className="text-xl font-bold text-navy mb-6">Interested in this property?</h3>
                  <form onSubmit={handleBooking} className="space-y-4">
                    <input name="name" required placeholder="Full Name" className="w-full h-12 rounded-md border border-slate-200 px-4 focus:ring-2 focus:ring-gold outline-none" />
                    <input name="email" type="email" required placeholder="Email Address" className="w-full h-12 rounded-md border border-slate-200 px-4 focus:ring-2 focus:ring-gold outline-none" />
                    <input name="phone" placeholder="Phone Number" className="w-full h-12 rounded-md border border-slate-200 px-4 focus:ring-2 focus:ring-gold outline-none" />
                    <textarea name="message" placeholder="I'm interested in..." className="w-full min-h-[100px] rounded-md border border-slate-200 p-4 focus:ring-2 focus:ring-gold outline-none" />
                    <Button 
                      type="submit" 
                      variant="gold" 
                      className="w-full h-14 font-bold uppercase tracking-widest"
                      disabled={status === 'loading'}
                    >
                      {status === 'loading' ? 'Requesting...' : 'Book a Viewing'}
                    </Button>
                    {status === 'error' && <p className="text-red-500 text-xs text-center">Failed to send. Please try again.</p>}
                  </form>
                  <div className="mt-8 pt-8 border-t border-slate-100">
                    <p className="text-sm text-center text-muted">Or chat directly via</p>
                    <Button variant="outline" className="w-full mt-4 flex gap-2 border-green-600 text-green-600 hover:bg-green-600 hover:text-white">
                       WhatsApp Us
                    </Button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
