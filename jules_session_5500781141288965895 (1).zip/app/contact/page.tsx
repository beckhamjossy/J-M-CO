import React from 'react';
import { ContactSection } from '@/components/ContactSection';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';

export default function ContactPage() {
  return (
    <div className="pt-24">
      <div className="bg-navy py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">Contact Us</h1>
          <p className="text-slate-300 max-w-2xl mx-auto text-lg">
            Whether you have a question about a listing or want to discuss an investment opportunity, our team is here to help.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-16 mb-24">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            { icon: <MapPin size={24} />, title: 'Visit Us', detail: '123 Luxury Lane, elite Plaza, Financial District' },
            { icon: <Phone size={24} />, title: 'Call Us', detail: '+1 (555) 123-4567' },
            { icon: <Mail size={24} />, title: 'Email Us', detail: 'hello@jmco-realestate.com' },
            { icon: <Clock size={24} />, title: 'Office Hours', detail: 'Mon-Sat: 9:00 AM - 6:00 PM' },
          ].map((item, i) => (
            <div key={i} className="bg-white p-8 rounded-2xl shadow-xl border border-slate-100 flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-full bg-gold/10 text-gold flex items-center justify-center mb-4">
                {item.icon}
              </div>
              <h3 className="font-bold text-navy mb-2">{item.title}</h3>
              <p className="text-sm text-muted">{item.detail}</p>
            </div>
          ))}
        </div>
      </div>

      <ContactSection />

      {/* Map Placeholder */}
      <section className="h-[500px] bg-slate-200 relative">
        <div className="absolute inset-0 flex items-center justify-center text-muted font-bold uppercase tracking-widest bg-[url('https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80')] bg-cover bg-center">
          <div className="bg-white/90 backdrop-blur-sm p-8 rounded-2xl shadow-2xl flex flex-col items-center">
            <MapPin size={40} className="text-gold mb-4" />
            <h3 className="text-navy text-xl font-bold mb-2">J&M CO Headquarters</h3>
            <p className="text-sm">Click to open in Google Maps</p>
          </div>
        </div>
      </section>
    </div>
  );
}
