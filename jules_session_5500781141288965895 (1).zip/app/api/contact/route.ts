import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    
    // In a real application, you would use a service like SendGrid, Mailgun, or AWS SES
    // to send an email to beckhamjossyo@gmail.com
    console.log('--- NOTIFICATION SENT ---');
    console.log('To: beckhamjossyo@gmail.com');
    console.log('Subject: New Booking/Inquiry from J&M CO Website');
    console.log('Data:', body);
    console.log('-------------------------');

    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 1000));

    return NextResponse.json({ 
      success: true, 
      message: 'Inquiry received and notification sent to admin.' 
    });
  } catch {
    return NextResponse.json({ 
      success: false, 
      message: 'Failed to process inquiry.' 
    }, { status: 500 });
  }
}
