import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Calendar, User, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/Button';

const POSTS = [
  {
    id: '1',
    title: 'Top 5 Real Estate Investment Trends for 2024',
    excerpt: 'Discover the emerging trends that are shaping the property market this year and how you can capitalize on them.',
    author: 'Marcus Sterling',
    date: 'Oct 12, 2023',
    category: 'Investment',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '2',
    title: 'A Guide to Buying Property for Diaspora Clients',
    excerpt: 'Navigating the process of remote property acquisition: everything you need to know about legalities and verification.',
    author: 'James Morrison',
    date: 'Nov 05, 2023',
    category: 'Guides',
    image: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
  },
  {
    id: '3',
    title: 'Why Premium Residential Spaces are the New Gold',
    excerpt: 'Exploring why high-end residential real estate remains one of the most stable asset classes in volatile times.',
    author: 'Sarah J&M',
    date: 'Dec 15, 2023',
    category: 'Market Trends',
    image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80'
  }
];

export default function BlogPage() {
  return (
    <div className="pt-24 pb-24">
      <div className="bg-slate-50 py-24 mb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="text-gold font-bold uppercase tracking-[0.2em] text-sm block mb-4">Market Insights</span>
          <h1 className="text-4xl md:text-6xl font-bold text-navy mb-6">The J&M CO Blog</h1>
          <p className="text-muted max-w-2xl mx-auto text-lg">
            Stay informed with the latest market trends, investment guides, and property buying tips from our team of experts.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
          {POSTS.map((post) => (
            <article key={post.id} className="flex flex-col h-full group">
              <div className="relative h-64 rounded-2xl overflow-hidden mb-6">
                <Image src={post.image} alt={post.title} fill className="object-cover group-hover:scale-110 transition-transform duration-500" />
                <div className="absolute top-4 left-4">
                  <span className="bg-white/90 backdrop-blur-sm text-navy px-3 py-1 rounded-md text-xs font-bold uppercase tracking-wider">
                    {post.category}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-4 text-sm text-muted mb-4">
                <span className="flex items-center gap-1"><Calendar size={14} /> {post.date}</span>
                <span className="flex items-center gap-1"><User size={14} /> {post.author}</span>
              </div>
              <h2 className="text-2xl font-bold text-navy mb-4 group-hover:text-gold transition-colors duration-300">
                {post.title}
              </h2>
              <p className="text-muted leading-relaxed mb-6 flex-grow">
                {post.excerpt}
              </p>
              <Link href={`/blog/${post.id}`} className="inline-flex items-center gap-2 text-navy font-bold hover:text-gold transition-colors">
                Read Full Article <ArrowRight size={18} />
              </Link>
            </article>
          ))}
        </div>
        
        <div className="mt-20 pt-20 border-t border-slate-100 flex justify-center">
          <Button variant="outline" size="lg">Load More Articles</Button>
        </div>
      </div>
    </div>
  );
}
