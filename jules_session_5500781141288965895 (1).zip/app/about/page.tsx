import React from 'react';
import Image from 'next/image';
import { AboutSection } from '@/components/AboutSection';
import { WhyChooseUs } from '@/components/WhyChooseUs';

export default function AboutPage() {
  return (
    <div className="pt-24">
      <div className="bg-navy py-24 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <Image src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80" alt="Background" fill className="object-cover" />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">Our Story</h1>
          <p className="text-slate-300 max-w-2xl mx-auto text-lg">
            Redefining the real estate landscape through excellence, integrity, and client-centric innovation since 2010.
          </p>
        </div>
      </div>
      
      <AboutSection />
      
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl font-bold text-navy mb-8">Our Mission</h2>
              <p className="text-muted text-lg leading-relaxed mb-6">
                To provide unparalleled real estate services that empower our clients to achieve their property goals with confidence and clarity. We believe in building long-term relationships based on trust and success.
              </p>
              <h2 className="text-3xl font-bold text-navy mb-8">Our Vision</h2>
              <p className="text-muted text-lg leading-relaxed">
                To be the most trusted and innovative real estate partner for local and international clients, setting the gold standard for luxury and investment property services globally.
              </p>
            </div>
            <div className="relative h-96 rounded-2xl overflow-hidden shadow-2xl">
              <Image src="https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" alt="Office" fill className="object-cover" />
            </div>
          </div>
        </div>
      </section>

      <WhyChooseUs />

      <section className="py-24 bg-navy text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-12">Leadership Excellence</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { name: 'James Morrison', role: 'CEO & Founder', image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80' },
              { name: 'Marcus Sterling', role: 'Head of Investment', image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80' },
              { name: 'Sarah J&M', role: 'Lead Architect', image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80' }
            ].map((member, i) => (
              <div key={i} className="group">
                <div className="relative h-80 rounded-2xl overflow-hidden mb-6 grayscale group-hover:grayscale-0 transition-all duration-500">
                  <Image src={member.image} alt={member.name} fill className="object-cover" />
                </div>
                <h4 className="text-xl font-bold text-gold">{member.name}</h4>
                <p className="text-slate-400">{member.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
