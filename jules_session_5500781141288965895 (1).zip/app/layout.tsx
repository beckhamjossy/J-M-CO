import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { RealTimeNotifications } from "@/components/RealTimeNotifications";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "J&M CO | Premium Real Estate & Investment",
  description: "J&M CO specializes in high-value residential, commercial, and investment properties. Expert guidance for home buyers and property investors.",
  keywords: ["real estate company", "property for sale", "investment property opportunities", "commercial real estate listings", "luxury homes"],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="scroll-smooth">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased min-h-screen flex flex-col`}
      >
        <Navbar />
        <main className="flex-grow">
          {children}
        </main>
        <RealTimeNotifications />
        <Footer />
      </body>
    </html>
  );
}
